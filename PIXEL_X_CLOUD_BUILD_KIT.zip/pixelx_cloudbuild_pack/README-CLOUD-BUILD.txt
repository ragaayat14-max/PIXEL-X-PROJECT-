PIXEL X PROJECT — BUILD APK TANPA ANDROID STUDIO DI HP

Paket ini memakai GitHub Actions untuk mengompilasi APK di server GitHub.
Tidak perlu memasang Android Studio di Redmi 12C.

LANGKAH:
1. Ekstrak paket PIXEL_X_CLOUD_BUILD_KIT.zip di HP (misalnya dengan ZArchiver).
2. Buka https://github.com dan masuk/buat akun.
3. Buat repository baru bernama PIXEL-X-PROJECT. Pilih Private jika ingin source tidak publik.
4. Di repository, pilih Add file > Upload files.
5. Unggah DUA item dari hasil ekstrak:
   - project-source.zip
   - folder .github (berisi workflows/build-apk.yml)
   Jika folder tersembunyi tidak terlihat di file picker, aktifkan tampilkan file tersembunyi atau unggah build-apk.yml melalui Add file > Create new file dengan path:
   .github/workflows/build-apk.yml
6. Commit perubahan ke branch main.
7. Buka tab Actions pada repository. Pilih workflow "Build PIXEL X PROJECT APK".
8. Tunggu workflow selesai. Jika hijau, buka run tersebut, gulir ke Artifacts, lalu unduh PIXEL-X-PROJECT-debug-APK.
9. Ekstrak hasil artifact ZIP; di dalamnya ada app-debug.apk. Buka APK untuk memasangnya.

Jika otomatis tidak mulai, tab Actions > Build PIXEL X PROJECT APK > Run workflow.
Jika gagal, buka run > Build debug APK dan salin log error merah untuk diperbaiki.

CATATAN:
- Build ini menghasilkan DEBUG APK untuk pengujian, bukan APK Play Store yang ditandatangani rilis.
- Source project tetap perlu diuji di perangkat. Keberhasilan cloud build tidak menjamin kamera/flash/screen share bekerja pada semua WebView/HP.
- Kamera, mikrofon, dan screen capture hanya boleh dimulai setelah izin sistem Android dan persetujuan pengguna.
- Jangan unggah token, password, API key, atau data pribadi ke repository.
