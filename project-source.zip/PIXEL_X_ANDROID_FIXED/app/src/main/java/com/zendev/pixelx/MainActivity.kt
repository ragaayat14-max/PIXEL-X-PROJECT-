package com.zendev.pixelx

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private val permissionRequestCode = 7102
    private val screenCaptureRequestCode = 7103

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        // Load bundled HTML from a secure HTTPS-like origin. getUserMedia() is
        // blocked on file:// origins by many Android WebView versions.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }
        webView.addJavascriptInterface(PixelNativeBridge(), "PixelNative")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    // Only grant web permissions to this app's bundled page.
                    if (request.origin.host != "appassets.androidplatform.net") {
                        request.deny()
                        return@runOnUiThread
                    }
                    val wantsCamera = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    val needed = mutableListOf<String>()
                    if (wantsCamera && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA)
                    if (wantsMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
                    if (needed.isEmpty()) request.grant(request.resources) else {
                        pendingWebPermission = request
                        requestPermissions(needed.toTypedArray(), permissionRequestCode)
                    }
                }
            }
            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingWebPermission == request) pendingWebPermission = null
            }
        }
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun requestNativeScreenShare() {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), screenCaptureRequestCode)
        } catch (e: Exception) {
            webView.evaluateJavascript("window.pxNativeShareError && window.pxNativeShareError(${jsString(e.message ?: "Tidak dapat membuka izin berbagi layar")})", null)
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == screenCaptureRequestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, ScreenShareService::class.java).apply {
                    action = ScreenShareService.ACTION_START
                    putExtra(ScreenShareService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenShareService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
                webView.evaluateJavascript("window.pxNativeShareStarted && window.pxNativeShareStarted()", null)
            } else {
                webView.evaluateJavascript("window.pxNativeShareError && window.pxNativeShareError('Izin berbagi layar dibatalkan.')", null)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                val cameraOk = !request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                val micOk = !request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (cameraOk && micOk) request.grant(request.resources) else request.deny()
            }
        }
    }

    inner class PixelNativeBridge {
        @JavascriptInterface fun hasTorch(): Boolean = try { findFlashCamera() != null } catch (_: Exception) { false }

        @JavascriptInterface fun setTorch(enabled: Boolean): String {
            return try {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    "Izin kamera belum diberikan. Aktifkan kamera terlebih dahulu dan setujui izin Android."
                } else {
                    val cameraId = findFlashCamera()
                    if (cameraId == null) {
                        "Flash tidak tersedia pada perangkat ini."
                    } else {
                        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
                        manager.setTorchMode(cameraId, enabled)
                        if (enabled) "Flash menyala." else "Flash mati."
                    }
                }
            } catch (e: Exception) {
                "Flash gagal diubah: ${e.message ?: "kesalahan perangkat"}"
            }
        }

        @JavascriptInterface fun requestScreenShare(): String {
            ScreenShareState.lastError = ""
            runOnUiThread { requestNativeScreenShare() }
            return "Membuka dialog persetujuan berbagi layar Android…"
        }

        @JavascriptInterface fun stopScreenShare(): String {
            runOnUiThread {
                startService(Intent(this@MainActivity, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP))
                stopService(Intent(this@MainActivity, ScreenShareService::class.java))
            }
            return "Perintah menghentikan sesi dikirim."
        }

        @JavascriptInterface fun getShareUrl(): String = ScreenShareState.shareUrl
        @JavascriptInterface fun getShareError(): String = ScreenShareState.lastError
        @JavascriptInterface fun getLocalPreviewUrl(): String = if (ScreenShareState.active && ScreenShareState.token.isNotEmpty()) "http://127.0.0.1:8765/frame.jpg?token=${ScreenShareState.token}" else ""
        @JavascriptInterface fun isScreenSharing(): Boolean = ScreenShareState.active

        @JavascriptInterface fun copyText(text: String): String {
            return try {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("PIXEL X screen share", text))
                "Link disalin."
            } catch (_: Exception) { "Tidak dapat menyalin link." }
        }

        @JavascriptInterface fun openAppSettings() {
            runOnUiThread {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = Uri.parse("package:$packageName") }
                startActivity(intent)
            }
        }
    }

    private fun jsString(value: String): String = "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ") + "'"

    private fun findFlashCamera(): String? {
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        for (id in manager.cameraIdList) {
            val c = manager.getCameraCharacteristics(id)
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            val flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            if (facing == CameraCharacteristics.LENS_FACING_BACK && flash) return id
        }
        return null
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("document.querySelectorAll('video').forEach(v=>{if(v.srcObject){v.srcObject.getTracks().forEach(t=>t.stop());v.srcObject=null;}})", null)
            webView.destroy()
        }
        super.onDestroy()
    }
}
