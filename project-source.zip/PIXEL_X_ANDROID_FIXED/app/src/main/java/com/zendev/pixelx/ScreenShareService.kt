package com.zendev.pixelx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayInputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/** State shared with the WebView bridge. The random token prevents casual access on the LAN. */
object ScreenShareState {
    @Volatile var active: Boolean = false
    @Volatile var shareUrl: String = ""
    @Volatile var token: String = ""
    @Volatile var latestJpeg: ByteArray? = null
    @Volatile var lastError: String = ""
}

class ScreenShareService : Service() {
    companion object {
        const val ACTION_START = "com.zendev.pixelx.action.START_SCREEN_SHARE"
        const val ACTION_STOP = "com.zendev.pixelx.action.STOP_SCREEN_SHARE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "pixel_screen_share"
        private const val NOTIFICATION_ID = 4812
        private const val PORT = 8765
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var server: FrameServer? = null
    private val stopped = AtomicBoolean(false)
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (ScreenShareState.active) return START_NOT_STICKY

        try {
            createNotificationChannel()
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val resultData = if (Build.VERSION.SDK_INT >= 33) {
                intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (resultCode == 0 || resultData == null) {
                stopSelf()
                return START_NOT_STICKY
            }

            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            beginCapture()
        } catch (e: Exception) {
            ScreenShareState.lastError = e.message ?: "Gagal memulai MediaProjection atau server berbagi lokal."
            ScreenShareState.active = false
            ScreenShareState.shareUrl = ""
            stopCapture()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun beginCapture() {
        val p = projection ?: throw IllegalStateException("MediaProjection tidak tersedia")
        val metrics = getScreenMetrics()
        val scale = minOf(1f, 720f / metrics.widthPixels.toFloat())
        val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(2).let { if (it % 2 == 0) it else it - 1 }
        val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(2).let { if (it % 2 == 0) it else it - 1 }

        captureThread = HandlerThread("PixelScreenCapture").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader -> processLatestImage(reader) }, captureHandler)

        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, captureHandler)

        virtualDisplay = p.createVirtualDisplay(
            "PIXEL X Screen Share",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )

        val token = UUID.randomUUID().toString().replace("-", "")
        ScreenShareState.lastError = ""
        ScreenShareState.token = token
        ScreenShareState.latestJpeg = null
        val ip = findLanIpv4()
        ScreenShareState.shareUrl = "http://$ip:$PORT/view?token=$token"
        server = FrameServer(PORT, token).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
        ScreenShareState.active = true
    }

    private fun processLatestImage(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < 300) return // about 3 frames/second is enough for a preview
            lastFrameAt = now
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
            val output = java.io.ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 42, output)
            ScreenShareState.latestJpeg = output.toByteArray()
            output.close()
            if (cropped !== full) cropped.recycle()
            full.recycle()
        } catch (_: Exception) {
            // A frame can be dropped during rotation or when Android stops projection.
        } finally {
            image?.close()
        }
    }

    private fun getScreenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        return metrics
    }

    private fun findLanIpv4(): String {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces().toList()
            val ordered = interfaces.sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            for (network in ordered) {
                if (!network.isUp || network.isLoopback) continue
                for (address in network.inetAddresses) {
                    if (address is Inet4Address && !address.isLoopbackAddress && address.isSiteLocalAddress) {
                        return address.hostAddress ?: continue
                    }
                }
            }
            "127.0.0.1"
        } catch (_: Exception) { "127.0.0.1" }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "PIXEL X screen sharing", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 4813, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("PIXEL X — berbagi layar aktif")
            .setContentText("Layar sedang dibagikan. Ketuk Stop untuk mengakhiri sesi.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", pending).build())
            .build()
    }

    private fun stopCapture() {
        if (!stopped.compareAndSet(false, true)) return
        ScreenShareState.active = false
        ScreenShareState.shareUrl = ""
        ScreenShareState.token = ""
        ScreenShareState.latestJpeg = null
        try { server?.stop() } catch (_: Exception) {}
        server = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        try { captureThread?.quitSafely() } catch (_: Exception) {}
        captureThread = null
        captureHandler = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    private class FrameServer(port: Int, private val expectedToken: String) : NanoHTTPD("0.0.0.0", port) {
        override fun serve(session: IHTTPSession): Response {
            val supplied = session.parameters["token"]?.firstOrNull().orEmpty()
            if (!MessageDigest.isEqual(supplied.toByteArray(), expectedToken.toByteArray())) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "Akses ditolak")
            }
            return when (session.uri) {
                "/view" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", viewerHtml())
                "/frame.jpg" -> {
                    val frame = ScreenShareState.latestJpeg
                        ?: return newFixedLengthResponse(Response.Status.SERVICE_UNAVAILABLE, "text/plain", "Menunggu frame layar")
                    newFixedLengthResponse(Response.Status.OK, "image/jpeg", ByteArrayInputStream(frame), frame.size.toLong()).apply {
                        addHeader("Cache-Control", "no-store, no-cache, must-revalidate")
                        addHeader("Access-Control-Allow-Origin", "*")
                    }
                }
                "/status" -> newFixedLengthResponse(Response.Status.OK, "application/json", "{\"active\":${ScreenShareState.active}}")
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Tidak ditemukan")
            }
        }

        private fun viewerHtml(): String = """<!doctype html><html lang="id"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PIXEL X Screen Share</title><style>body{margin:0;background:#090914;color:#fff;font:16px system-ui;text-align:center}header{padding:14px}img{display:block;width:100%;height:auto;max-height:85vh;object-fit:contain;background:#000}small{color:#b9b4d5}</style><header><b>PIXEL X · LIVE SCREEN</b><br><small>Pratinjau layar yang dibagikan oleh pemilik perangkat</small></header><img id="frame" alt="Pratinjau layar"><script>const token=new URLSearchParams(location.search).get('token');const img=document.getElementById('frame');function refresh(){img.src='/frame.jpg?token='+encodeURIComponent(token)+'&t='+Date.now()}refresh();setInterval(refresh,450);</script></html>"""
    }
}
