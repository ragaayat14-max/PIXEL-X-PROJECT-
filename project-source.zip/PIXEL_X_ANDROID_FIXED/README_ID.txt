PIXEL X PROJECT — ANDROID NATIVE BRIDGE + HTML UI

IDENTITAS
- Nama aplikasi: PIXEL X PROJECT
- Ikon launcher: logo PIXEL X hitam-putih dari gambar yang diberikan.
- Tampilan utama tetap memakai HTML asli di app/src/main/assets/index.html.

PERBAIKAN PENTING
- HTML dimuat lewat AndroidX WebViewAssetLoader pada origin HTTPS lokal appassets.androidplatform.net. Ini diperlukan agar API kamera browser bekerja lebih konsisten di WebView.
- Izin kamera/mikrofon WebView diteruskan ke dialog izin Android dan hanya diberikan jika pengguna menyetujui.
- Kontrol flash memakai CameraManager Android; UI hanya mengubah status ON/OFF jika perintah native benar-benar berhasil.
- Berbagi layar memakai MediaProjection Android, foreground service bertipe mediaProjection, notifikasi Stop, serta penghentian resource saat sesi berakhir.
- Pratinjau lokal tampil di Device Center.
- Link berbagi dapat dibuka browser perangkat lain pada Wi-Fi/LAN yang sama. Penerima hanya melihat, tidak mendapat kontrol sentuh/ketik.

CARA BUILD APK
1. Ekstrak ZIP.
2. Buka folder PIXEL_X_ANDROID_FIXED di Android Studio (bukan file HTML-nya).
3. Gunakan Android Studio dengan JDK bawaan dan Android SDK Platform 35 terpasang.
4. Sambungkan internet saat Gradle Sync agar plugin/dependency dapat diunduh.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug, jika build berhasil, berada di app/build/outputs/apk/debug/app-debug.apk.

CARA PAKAI
Kamera:
1. Buka Device Center.
2. Tekan Kamera depan atau Kamera belakang.
3. Setujui izin kamera Android.
4. Tekan Stop kamera untuk mengakhiri.

Flash:
1. Berikan izin kamera terlebih dahulu dengan memulai kamera.
2. Tekan tombol flash. Flash hanya tersedia jika kamera belakang perangkat memiliki LED dan Android mengizinkannya.

Berbagi layar dua mode:
1. Pastikan HP pengirim dan penerima berada pada Wi-Fi/LAN yang sama.
2. Di PIXEL X tekan Mulai berbagi layar.
3. Setujui dialog MediaProjection Android. Tidak ada perekaman tersembunyi; setiap sesi memerlukan persetujuan sistem.
4. Pratinjau lokal tampil di aplikasi. Salin link yang muncul untuk dibuka di browser HP penerima.
5. Tekan Stop di aplikasi atau notifikasi untuk mengakhiri sesi.

BATASAN & PRIVASI
- Berbagi ke HP lain pada versi ini hanya berfungsi di jaringan Wi-Fi/LAN yang sama, bukan internet publik.
- Tampilan dikirim sebagai JPEG berkala, dibatasi sekitar 720 piksel dan sekitar 3 frame/detik; ini pratinjau ringan, bukan video konferensi.
- Link sesi berisi token acak. Jangan bagikan kepada orang yang tidak dipercaya; siapa pun yang memiliki link selama sesi aktif dapat melihat layar.
- Penerima hanya dapat melihat. Tidak ada kontrol sentuh/ketik jarak jauh.
- Android dapat menghentikan sesi ketika izin dicabut, layar dikunci, atau sistem menghentikan proyeksi.
- Kamera, flash, dan fitur berbagi layar bergantung pada izin, perangkat, versi Android, serta implementasi WebView.
- HTML murni tidak dapat mengendalikan seluruh sistem Android. Fungsi native harus tetap berjalan melalui APK ini.

STATUS PEMERIKSAAN DI LINGKUNGAN PEMBUATAN
- 13 blok JavaScript: lolos node --check.
- AndroidManifest.xml: XML valid.
- Arsip ZIP: akan diperiksa setelah dibuat.
- APK belum dikompilasi di lingkungan ini karena Android SDK dan Gradle tidak tersedia. Karena itu, jangan anggap APK sudah berhasil dibuat sampai build Android Studio selesai.
